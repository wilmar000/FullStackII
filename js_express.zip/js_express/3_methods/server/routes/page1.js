const express = require('express')
const router = express.Router()
router.use((req, res, next) => {
    console.log('Time: ', Date.now())
    next()
})
router.get('/', async (req,res)=>{
    res.send("this is page1")
})
module.exports = router