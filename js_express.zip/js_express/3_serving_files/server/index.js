const express = require('express')
const appServer = express()
const port = 80
appServer.get('/', express.static('public/index.html'))
appServer.listen(port, () => console.log(`Ok on port ${port}`))
appServer.use(express.static('public'))