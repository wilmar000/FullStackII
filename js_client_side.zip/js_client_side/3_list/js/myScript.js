// Welcome message with a pause





try {
    window.onalert = userAlertMsg();
    var speciesList = document.getElementById('speciesList').innerText;
    var featureList = docuemnt.getElementById('featureList').innerText;
    var countriesList = coument.getElementById('countriesList').innerText;

    function userAlertMsg() {
        setTimeout(() => {
            userAlertMsg = "List of Species: \n" + speciesList;
            userAlertMsg = "List of features; \n" + featureList;
            userAlertMsg = "List of Countries with mor population \n" + countriesList;
            alert(AlertMsg);
        }, 2000);
    } 
}
catch (err) {
    document.getElementById("este texto es opcional").innerHTML = err.message;
}
finally {
    // If needed, you can do something here regardless of what happens in try/catch
