let numeroArr = 102
let articulo = 'world'
let colors = 'white'


try {

    function sayNumbers(numeroArr) {
        return numeroArr
    }
    document.getElementById("numbersss").innerHTML = `we want to live ${numeroArr} years and not less than ${sayNumbers(numeroArr)}`;

 
}
catch (err) {
    document.getElementById("resultsss").innerHTML = err.message;
}
finally {
    console.log('everything is ok');
}

try {
function sayArticulo(articulo) {
    return articulo;
}
document.getElementById("wordsss").innerHTML = `we live in the ${sayArticulo(articulo)}`;
}
catch (err) {
    document.getElementById("resultsss").innerHTML = err.message;
}
finally {
    console.log('everything is ok');
}

try {
function sayColor(colors) {
    return colors
}
document.getElementById("colorsss").innerHTML = `${sayColor(colors)} is all colors togheter`;
}
catch (err) {
    document.getElementById("resultsss").innerHTML = err.message;
}
finally {
    console.log('everything is ok');
}

// /// numbers bigger than 200
// try {
//     texto += "<ul>";
//     // for (i = 0; i < extn; i++) {
//     //     if (numero > numeroArr[i]) {
//     //         texto += "<li>" + numeroArr[i] + "</li>";
//     //     }
//     //     else {
//     //         texto += `<br> the number: ${numeroArr[i]} is bigger than ${numero}`
//     //     }
//     // }
//     // texto += "</ul>";

//     // document.getElementById("numbersss").innerHTML = texto;

//     let i = 0
//     while (i < extn) {
//         if (numero > numeroArr[i]) {
//             texto += "<li>" + numeroArr[i] + "</li>";
//         }
//         else {
//             texto += `<br> the number: ${numeroArr[i]} is bigger than ${numero}`
//         }
//     }
//     // words with "w"
//     texto1 += "<ul>";
//     // for (i = 0; i < ext; i++) {
//     //     if (articulo[i] >= letra) {
//     //         texto1 += "<li>" + articulo[i] + "</li>";
//     //     }
//     //     else {
//     //         texto1 += `<br> The article: ${articulo[i]} do not begin with ${letra}`
//     //     }

//     // }

//     // texto1 += "</ul>";

//     while (i < ext) {
//         if (articulo[i] >= letra) {
//             texto1 += "<li>" + articulo[i] + "</li>";
//         }
//         else {
//             texto1 += `<br> The article: ${articulo[i]} do not begin with ${letra}`
//         }
//     }

//     document.getElementById("wordsss").innerHTML = texto1;

// }
// catch (err) {
//     document.getElementById("resultsss").innerHTML = err.message;
// }
// finally {
//     console.log('everything is ok');
// }