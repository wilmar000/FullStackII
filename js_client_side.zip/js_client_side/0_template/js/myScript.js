// Welcome message with a pause

function sayHelloFunction(){
    var welcomeMsg = "Este es un mensaje de bienvenida";
    console.log(welcomeMsg);
}


try{
    alert("Welcome to know more about Brown Bears");
}
catch(err){
    document.getElementById("demoFullStack").innerHTML = err.message;
} 
finally{
    console.log("Just Trying");
} 

// Using Alert Box
window.alert('Also, you are gonna see what year is now in console log')
// This is a console log message
console.log('This year is = ' + 20 + 19);