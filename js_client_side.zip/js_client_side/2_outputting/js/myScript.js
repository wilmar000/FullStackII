
function myFunction() {
    var message, x;
    message = document.getElementById("p01"); // this is only to shoy property of message
    message.innerHTML = ""; // this is only to show this is a cartacter
    x = document.getElementById("demo").value;
    try {
        if (x == "") throw "is empty";
    if (isNaN(x)) throw "is not a number";
        x = Number(x);    
        if (x > 1000) throw "is too high";
        if (x < 100) throw "is too low";
    }
    catch (err) {
        message.innerHTML = "This input " + err;
    }
    finally {
        document.getElementById("demo").value = "";
        throw "is OK";
    }
}
