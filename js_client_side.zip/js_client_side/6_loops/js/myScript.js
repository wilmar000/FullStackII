let articulo = ["world", "whiteboard", "blackrock"]
let numeroArr = [102, 340, 400]
let numero = 200
let letra = "w"
let ext = articulo.length
let extn = numeroArr.length
let texto = `numbers less than ${numero}:`
let texto1 = `words starting with ${letra} :`

/// numbers bigger than 200
try {
    texto += "<ul>";
    for (i = 0; i < extn; i++) {
        if (numero > numeroArr[i]) {
            texto += "<li>" + numeroArr[i] + "</li>";

        }
        else {
            texto += `<br> the number: ${numeroArr[i]} is bigger than ${numero}`
        }
    }
    texto += "</ul>";

    document.getElementById("numbersss").innerHTML = texto;

    // words with "w"
    texto1 += "<ul>";
    for (i = 0; i < ext; i++) {
        if (articulo[i] >= letra) {
            texto1 += "<li>" + articulo[i] + "</li>";
        }
        else {
            texto1 += `<br> The article: ${articulo[i]} do not begin with ${letra}`
        }

    }

    texto1 += "</ul>";

    document.getElementById("wordsss").innerHTML = texto1;

}
catch (err) {
    document.getElementById("resultsss").innerHTML = err.message;
}
finally {
    console.log('everything is ok');
}